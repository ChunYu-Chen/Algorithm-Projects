There is a shopping.txt in the current folder, you can overwrite it if you have another file to test.

Then, execute the following commands:
g++ shopping.cpp -o shopping
./shopping

after that, a result.txt will be generated.