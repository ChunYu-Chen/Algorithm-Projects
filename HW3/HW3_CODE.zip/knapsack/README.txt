execute the following commands on linux system:
g++ knapsack.cpp -o knapsack
./knapsack