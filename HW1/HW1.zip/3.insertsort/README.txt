on the linux OS
put the "data.txt" which you choose into this folder
type the command "./insertsort"
then it will generate a "insert.txt"

if it cannot be executed  
plz type 
- make clean
- make
- ./insertsort