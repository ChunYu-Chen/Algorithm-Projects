on the linux OS
put the "data.txt" which you choose into this folder
type the command "./mergesort"
then it will generate a "merge.txt"

if it cannot be executed  
plz type 
- make clean
- make
- ./mergesort