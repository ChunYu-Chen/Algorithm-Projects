on the linux OS
type the command "./mergeTime"
then it will print numbers of n and their running times for ten times.

if it cannot be executed  
plz type 
- make clean
- make
- ./mergeTime 