on the linux OS
put the "data.txt" which you choose into this folder
type the command "./Mergesort3"
then it will generate a "merge3.txt"

if it cannot be executed  
plz type 
- make clean
- make
- ./Mergesort3